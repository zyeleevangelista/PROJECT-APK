package com.example.lockvideorecorder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Size;
import android.view.Surface;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

/**
 * Visible, user-initiated camera foreground service. Recording begins while the app is
 * open and may continue after the display is locked, subject to OEM restrictions.
 */
public class RecordingService extends Service {
    public static final String ACTION_START = "com.example.lockvideorecorder.START";
    public static final String ACTION_STOP = "com.example.lockvideorecorder.STOP";
    public static final String EXTRA_AUDIO = "audio";
    public static final String EXTRA_FRONT_CAMERA = "front_camera";
    public static final String EXTRA_DISPLAY_ROTATION = "display_rotation";

    public static volatile boolean isActive = false;
    public static volatile boolean hasStartedFrames = false;

    private static final String TAG = "LockVideoRecorder";
    private static final String CHANNEL_ID = "active_recording";
    private static final int ACTIVE_NOTIFICATION_ID = 80;
    private static final int RESULT_NOTIFICATION_ID = 81;
    // Automatic end of recording to avoid accidental indefinite recording and full storage.
    private static final int MAX_DURATION_MS = 60 * 60 * 1000;
    private static final long MAX_FILE_BYTES = 2_000_000_000L;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private MediaRecorder recorder;
    private ParcelFileDescriptor videoFd;
    private Uri videoUri;
    private boolean stopping = false;
    private boolean recorderStarted = false;
    private PowerManager.WakeLock cpuWakeLock;
    private NotificationManager notifier;

    @Override public void onCreate() {
        super.onCreate();
        cameraThread = new HandlerThread("video-capture");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        notifier = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Video recording", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Visible status while camera recording is active");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        notifier.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            if (cameraHandler != null) cameraHandler.post(() -> finishCapture(null));
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || isActive) {
            if (!isActive) stopSelf(startId);
            return START_NOT_STICKY;
        }

        final boolean withAudio = intent.getBooleanExtra(EXTRA_AUDIO, false);
        final boolean frontCamera = intent.getBooleanExtra(EXTRA_FRONT_CAMERA, false);
        final int displayRotation = intent.getIntExtra(EXTRA_DISPLAY_ROTATION, Surface.ROTATION_0);

        // Android 14+ validates service types and while-in-use permissions immediately.
        try {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
            if (withAudio && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            startForeground(ACTIVE_NOTIFICATION_ID, activeNotification("Preparing camera…"), types);
        } catch (RuntimeException ex) {
            Log.e(TAG, "Cannot start camera foreground service", ex);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        isActive = true;
        hasStartedFrames = false;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            cpuWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "LockVideoRecorder:CameraCapture");
            cpuWakeLock.setReferenceCounted(false);
            cpuWakeLock.acquire(MAX_DURATION_MS + 2 * 60 * 1000L);
        } catch (Exception ex) {
            Log.w(TAG, "Could not obtain a partial wakelock", ex);
        }
        cameraHandler.post(() -> beginCapture(frontCamera, withAudio, displayRotation));
        return START_NOT_STICKY;
    }

    private Notification activeNotification(String text) {
        Intent appIntent = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 1, appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stopIntent = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 2, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Lock Video Recorder")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause, "Stop & save", stop).build())
                .build();
    }

    private void beginCapture(boolean front, boolean withAudio, int displayRotation) {
        if (stopping) return;
        try {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                throw new SecurityException("Camera permission not granted");
            if (withAudio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                throw new SecurityException("Microphone permission not granted");

            CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
            String cameraId = pickCamera(manager, front);
            if (cameraId == null) throw new IllegalStateException("No camera available");

            CameraCharacteristics properties = manager.getCameraCharacteristics(cameraId);
            Size size = pickRecordingSize(properties);
            createVideoFile();
            setupMediaRecorder(size, withAudio, calculateOrientation(properties, displayRotation));
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    if (stopping) {
                        device.close();
                        return;
                    }
                    cameraDevice = device;
                    configureSession();
                }
                @Override public void onDisconnected(CameraDevice device) {
                    device.close();
                    if (device == cameraDevice) cameraDevice = null;
                    failCapture("Camera disconnected");
                }
                @Override public void onError(CameraDevice device, int error) {
                    device.close();
                    if (device == cameraDevice) cameraDevice = null;
                    failCapture("Camera error " + error);
                }
            }, cameraHandler);
        } catch (Exception ex) {
            Log.e(TAG, "Unable to initialize camera", ex);
            failCapture("Unable to record: " + readable(ex));
        }
    }

    private String pickCamera(CameraManager manager, boolean front)
            throws CameraAccessException {
        String fallback = null;
        int desiredFacing = front ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;
        for (String id : manager.getCameraIdList()) {
            if (fallback == null) fallback = id;
            Integer facing = manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == desiredFacing) return id;
        }
        return fallback;
    }

    private Size pickRecordingSize(CameraCharacteristics camera) {
        StreamConfigurationMap map = camera.get(
                CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] choices = map == null ? null : map.getOutputSizes(MediaRecorder.class);
        if (choices == null || choices.length == 0) return new Size(1280, 720);
        // Prefer a mainstream 16:9 video size. Cap at 1080p for heat/storage.
        Size best = null;
        for (Size size : choices) {
            int w = size.getWidth();
            int h = size.getHeight();
            if (w <= 1920 && h <= 1080 && w >= 640 && h >= 480) {
                if (Math.abs(w * 9 - h * 16) <= 16 &&
                        (best == null || w * h > best.getWidth() * best.getHeight()))
                    best = size;
            }
        }
        if (best != null) return best;
        Arrays.sort(choices, Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()));
        // Fallback to the smallest advertised size if no supported 16:9 match.
        return choices[0];
    }

    private int calculateOrientation(CameraCharacteristics camera, int rotation) {
        Integer sensorOrientation = camera.get(CameraCharacteristics.SENSOR_ORIENTATION);
        Integer lens = camera.get(CameraCharacteristics.LENS_FACING);
        int sensor = sensorOrientation == null ? 90 : sensorOrientation;
        int degrees;
        switch (rotation) {
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
            default: degrees = 0;
        }
        if (lens != null && lens == CameraCharacteristics.LENS_FACING_FRONT)
            return (sensor + degrees) % 360;
        return (sensor - degrees + 360) % 360;
    }

    private void createVideoFile() throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "LVR_" + timestamp + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LockVideoRecorder");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (videoUri == null) throw new IOException("Cannot create destination video");
        videoFd = getContentResolver().openFileDescriptor(videoUri, "rw");
        if (videoFd == null) throw new IOException("Cannot write destination video");
    }

    private void setupMediaRecorder(Size size, boolean withAudio, int orientation) throws IOException {
        recorder = new MediaRecorder();
        if (withAudio) recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(size.getWidth(), size.getHeight());
        recorder.setVideoFrameRate(30);
        int pixels = size.getWidth() * size.getHeight();
        recorder.setVideoEncodingBitRate(pixels >= 1920 * 1080 ? 6_000_000 : 3_500_000);
        if (withAudio) {
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128_000);
            recorder.setAudioSamplingRate(44100);
        }
        recorder.setOrientationHint(orientation);
        recorder.setOutputFile(videoFd.getFileDescriptor());
        recorder.setMaxDuration(MAX_DURATION_MS);
        recorder.setMaxFileSize(MAX_FILE_BYTES);
        recorder.setOnInfoListener((mr, what, extra) -> {
            if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED ||
                    what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) {
                cameraHandler.post(() -> finishCapture(null));
            }
        });
        recorder.setOnErrorListener((mr, what, extra) ->
                cameraHandler.post(() -> failCapture("Video recorder error: " + what)));
        recorder.prepare();
    }

    private void configureSession() {
        if (stopping || cameraDevice == null || recorder == null) return;
        try {
            final Surface videoSurface = recorder.getSurface();
            final CaptureRequest.Builder request = cameraDevice.createCaptureRequest(
                    CameraDevice.TEMPLATE_RECORD);
            request.addTarget(videoSurface);
            request.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            cameraDevice.createCaptureSession(Collections.singletonList(videoSurface),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession created) {
                            if (stopping) {
                                created.close();
                                return;
                            }
                            session = created;
                            try {
                                session.setRepeatingRequest(request.build(), null, cameraHandler);
                                recorder.start();
                                recorderStarted = true;
                                hasStartedFrames = true;
                                notifier.notify(ACTIVE_NOTIFICATION_ID,
                                        activeNotification("Recording video • Tap Stop to save"));
                            } catch (Exception e) {
                                Log.e(TAG, "Could not begin recording", e);
                                failCapture("Recording could not start");
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession created) {
                            created.close();
                            failCapture("Camera session configuration failed");
                        }
                    }, cameraHandler);
        } catch (Exception e) {
            Log.e(TAG, "Could not open video session", e);
            failCapture("Camera session setup failed");
        }
    }

    private void failCapture(String message) {
        if (stopping) return;
        Log.e(TAG, message);
        finishCapture(message);
    }

    /** Called on the camera handler thread to serialize camera and recorder operations. */
    private void finishCapture(String error) {
        if (stopping) return;
        stopping = true;
        hasStartedFrames = false;

        if (session != null) {
            try { session.stopRepeating(); } catch (Exception ignored) { }
            try { session.abortCaptures(); } catch (Exception ignored) { }
            try { session.close(); } catch (Exception ignored) { }
            session = null;
        }
        if (cameraDevice != null) {
            try { cameraDevice.close(); } catch (Exception ignored) { }
            cameraDevice = null;
        }
        boolean goodFile = recorderStarted;
        if (recorder != null) {
            if (recorderStarted) {
                try { recorder.stop(); }
                catch (RuntimeException e) {
                    Log.e(TAG, "MediaRecorder cannot finalize file", e);
                    goodFile = false;
                }
            }
            try { recorder.reset(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        recorderStarted = false;
        if (videoFd != null) {
            try { videoFd.close(); } catch (IOException ignored) { }
            videoFd = null;
        }

        if (videoUri != null) {
            if (goodFile) {
                try {
                    ContentValues published = new ContentValues();
                    published.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(videoUri, published, null, null);
                } catch (Exception e) {
                    goodFile = false;
                    error = "Could not publish recorded video";
                }
            }
            if (!goodFile) {
                try { getContentResolver().delete(videoUri, null, null); }
                catch (Exception ignored) { }
            }
        }

        Uri completedVideo = goodFile ? videoUri : null;
        videoUri = null;
        isActive = false;
        releaseWakeLock();
        try { stopForeground(STOP_FOREGROUND_REMOVE); }
        catch (Exception ignored) { }
        if (completedVideo != null) showSavedNotification(completedVideo);
        else if (error != null) showErrorNotification(error);
        else showErrorNotification("Recording stopped before a video could be saved");
        stopSelf();
    }

    private void showSavedNotification(Uri uri) {
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "video/mp4");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        PendingIntent open = PendingIntent.getActivity(this, 3, view,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_save)
                .setContentTitle("Video saved")
                .setContentText("Saved in Movies / LockVideoRecorder")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        notifier.notify(RESULT_NOTIFICATION_ID, notification);
    }

    private void showErrorNotification(String error) {
        Intent app = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 1, app,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Video recording stopped")
                .setContentText(error)
                .setStyle(new Notification.BigTextStyle().bigText(error))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        notifier.notify(RESULT_NOTIFICATION_ID, notification);
    }

    private void releaseWakeLock() {
        if (cpuWakeLock != null) {
            try { if (cpuWakeLock.isHeld()) cpuWakeLock.release(); }
            catch (Exception ignored) { }
            cpuWakeLock = null;
        }
    }

    private static String readable(Exception exception) {
        return exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
    }

    @Override public void onDestroy() {
        // Ordinarily finishCapture() runs before destruction. Handle abrupt teardown defensively.
        if (!stopping && cameraHandler != null) {
            cameraHandler.post(() -> {
                if (!stopping) finishCapture("Recording interrupted");
            });
        }
        if (cameraThread != null) cameraThread.quitSafely();
        releaseWakeLock();
        isActive = false;
        hasStartedFrames = false;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
