package com.example.lockvideorecorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 200;
    private static final int BACK_CAMERA = 300;
    private static final int FRONT_CAMERA = 301;
    private static final int INK = Color.rgb(14, 20, 32);
    private static final int SURFACE = Color.rgb(29, 37, 52);
    private static final int TEXT = Color.rgb(242, 246, 251);
    private static final int MUTED = Color.rgb(170, 184, 202);
    private static final int ACCENT = Color.rgb(89, 173, 253);

    private RadioGroup cameraGroup;
    private CheckBox audioCheck;
    private Button recordButton;
    private TextView statusText;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() {
            refreshStatus();
            uiHandler.postDelayed(this, 1200);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(INK);
        getWindow().setNavigationBarColor(INK);
        renderUI();
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(refreshTask);
        uiHandler.post(refreshTask);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(refreshTask);
        super.onPause();
    }

    private void renderUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(INK);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(24), dp(42), dp(24), dp(32));
        scroll.addView(main);

        TextView eyebrow = label("PRIVATE / ON-DEVICE", 12, ACCENT, Typeface.BOLD);
        main.addView(eyebrow);
        TextView title = label("Lock Video Recorder", 29, TEXT, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(10);
        main.addView(title, titleLp);
        TextView subtitle = label("Start recording while unlocked, then lock the screen. Keep a visible notification and stop at any time.", 15, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(-1, -2);
        descLp.topMargin = dp(12);
        main.addView(subtitle, descLp);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(20), dp(20), dp(20));
        panel.setBackground(rounded(SURFACE, 18));
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(-1, -2);
        panelLp.topMargin = dp(28);
        main.addView(panel, panelLp);

        TextView statusHeader = label("RECORDER STATUS", 12, MUTED, Typeface.BOLD);
        panel.addView(statusHeader);
        statusText = label("Not recording", 19, TEXT, Typeface.BOLD);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(8);
        statusLp.bottomMargin = dp(22);
        panel.addView(statusText, statusLp);

        panel.addView(label("CAMERA", 12, MUTED, Typeface.BOLD));
        cameraGroup = new RadioGroup(this);
        cameraGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton back = new RadioButton(this);
        back.setId(BACK_CAMERA);
        back.setText("Rear");
        styleRadio(back);
        RadioButton front = new RadioButton(this);
        front.setId(FRONT_CAMERA);
        front.setText("Front");
        styleRadio(front);
        cameraGroup.addView(back);
        cameraGroup.addView(front);
        cameraGroup.check(BACK_CAMERA);
        LinearLayout.LayoutParams camLp = new LinearLayout.LayoutParams(-1, -2);
        camLp.topMargin = dp(8);
        panel.addView(cameraGroup, camLp);

        audioCheck = new CheckBox(this);
        audioCheck.setText("Record microphone audio");
        audioCheck.setTextColor(TEXT);
        audioCheck.setTextSize(15);
        audioCheck.setButtonTintList(ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams audioLp = new LinearLayout.LayoutParams(-1, -2);
        audioLp.topMargin = dp(18);
        panel.addView(audioCheck, audioLp);

        recordButton = new Button(this);
        recordButton.setAllCaps(false);
        recordButton.setTextSize(17);
        recordButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, dp(60));
        buttonLp.topMargin = dp(26);
        main.addView(recordButton, buttonLp);
        recordButton.setOnClickListener(v -> {
            if (RecordingService.isActive) {
                Intent stop = new Intent(this, RecordingService.class);
                stop.setAction(RecordingService.ACTION_STOP);
                startService(stop);
                statusText.setText("Finalizing video…");
            } else {
                requestStart();
            }
        });

        Button openVideos = new Button(this);
        openVideos.setAllCaps(false);
        openVideos.setText("Open recorded videos");
        openVideos.setTextColor(TEXT);
        openVideos.setBackground(rounded(SURFACE, 12));
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(-1, dp(56));
        openLp.topMargin = dp(12);
        main.addView(openVideos, openLp);
        openVideos.setOnClickListener(v -> {
            try {
                Intent browse = new Intent(Intent.ACTION_VIEW);
                browse.setDataAndType(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*");
                startActivity(browse);
            } catch (Exception ex) {
                Toast.makeText(this, "Open the Files or Gallery app and look in Movies / LockVideoRecorder", Toast.LENGTH_LONG).show();
            }
        });

        TextView note = label("Videos save to Movies / LockVideoRecorder. A foreground recording notification stays visible. Device manufacturers may limit camera access when locked.", 13, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(24);
        main.addView(note, noteLp);

        setContentView(scroll);
        refreshStatus();
    }

    private void styleRadio(RadioButton button) {
        button.setTextColor(TEXT);
        button.setTextSize(15);
        button.setButtonTintList(ColorStateList.valueOf(ACCENT));
        button.setPadding(0, 0, dp(28), 0);
    }

    private TextView label(String value, int sp, int color, int typeface) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, typeface);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }

    private int dp(int value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private void refreshStatus() {
        if (recordButton == null) return;
        boolean recording = RecordingService.isActive;
        recordButton.setText(recording ? "Stop & save video" : "Start video recording");
        recordButton.setBackground(rounded(recording ? Color.rgb(217, 73, 80) : ACCENT, 12));
        recordButton.setTextColor(recording ? Color.WHITE : INK);
        statusText.setText(recording ? (RecordingService.hasStartedFrames ? "Recording • screen can be locked" : "Preparing camera…") : "Not recording");
        cameraGroup.setEnabled(!recording);
        for (int i = 0; i < cameraGroup.getChildCount(); i++) cameraGroup.getChildAt(i).setEnabled(!recording);
        audioCheck.setEnabled(!recording);
    }

    private List<String> missingPermissions() {
        List<String> list = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.CAMERA);
        if (audioCheck.isChecked() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.POST_NOTIFICATIONS);
        return list;
    }

    private void requestStart() {
        List<String> missing = missingPermissions();
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
            return;
        }
        startCapture();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (missingPermissions().isEmpty()) startCapture();
        else Toast.makeText(this, "Camera and notification permissions are required. Microphone access is only required if audio is on.", Toast.LENGTH_LONG).show();
    }

    private void startCapture() {
        Intent intent = new Intent(this, RecordingService.class);
        intent.setAction(RecordingService.ACTION_START);
        intent.putExtra(RecordingService.EXTRA_FRONT_CAMERA, cameraGroup.getCheckedRadioButtonId() == FRONT_CAMERA);
        intent.putExtra(RecordingService.EXTRA_AUDIO, audioCheck.isChecked());
        intent.putExtra(RecordingService.EXTRA_DISPLAY_ROTATION, getWindowManager().getDefaultDisplay().getRotation());
        try {
            startForegroundService(intent);
            statusText.setText("Starting recorder…");
        } catch (Exception e) {
            Toast.makeText(this, "Cannot start recording: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
